'use client';

import { useState } from 'react';
import { Header } from '@/components/Header';

/**
 * Client-side layout wrapper with Header and theme management
 */
export function LayoutClient({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const navigation = [
    { label: 'Главная', href: '/', active: false },
    { label: 'UI Kit', href: '/ui-kit', active: false },
    { label: 'Design System', href: '/design-system', active: false },
  ];

  return (
    <div className={theme === 'dark' ? 'dark' : ''}>
      <Header
        navigation={navigation}
        currentTheme={theme}
        onThemeToggle={setTheme}
      />
      <main>{children}</main>
    </div>
  );
}
