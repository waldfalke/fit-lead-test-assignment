/**
 * Hamburger menu icon for mobile navigation
 * Using Lucide React icon library
 */
export { Menu as MenuIcon } from 'lucide-react';
