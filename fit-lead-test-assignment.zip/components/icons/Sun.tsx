/**
 * Sun icon for light theme toggle
 * Using Lucide React icon library
 */
export { Sun as SunIcon } from 'lucide-react';
