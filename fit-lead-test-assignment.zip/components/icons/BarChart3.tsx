/**
 * Bar Chart icon - for analytics, tools, reporting, dashboard
 * Using Lucide React icon library
 */
export { BarChart3 as BarChart3Icon } from 'lucide-react';
