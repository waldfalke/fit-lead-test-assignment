/**
 * Close/X icon for closing mobile menu
 * Using Lucide React icon library
 */
export { X as XIcon } from 'lucide-react';
