/**
 * Headphones icon - for support, customer service, 24/7
 * Using Lucide React icon library
 */
export { Headphones as HeadphonesIcon } from 'lucide-react';
