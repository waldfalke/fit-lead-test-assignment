/**
 * Moon icon for dark theme toggle
 * Using Lucide React icon library
 */
export { Moon as MoonIcon } from 'lucide-react';
