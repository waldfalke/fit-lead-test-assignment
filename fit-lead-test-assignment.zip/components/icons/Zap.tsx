/**
 * Zap icon - for speed, fast, lightning, quick payouts
 * Using Lucide React icon library
 */
export { Zap as ZapIcon } from 'lucide-react';
