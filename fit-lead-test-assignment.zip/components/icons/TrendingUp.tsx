/**
 * Trending Up icon - for growth, profit, high payouts
 * Using Lucide React icon library
 */
export { TrendingUp as TrendingUpIcon } from 'lucide-react';
