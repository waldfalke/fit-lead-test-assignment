# ✅ px Canonical Implementation - COMPLETE

**Date:** 2025-01-04  
**Status:** Production-ready  
**Approach:** px in tokens.json → rem in generated CSS

---

## 🎯 **What Changed:**

### **Before (rem canonical):**
```json
{
  "spacing": {
    "4": { "value": "1rem", "comment": "16px" }
  }
}
```

### **After (px canonical):**
```json
{
  "spacing": {
    "4": {
      "value": 16,
      "type": "dimension",
      "unit": "px",
      "comment": "Default spacing, buttons"
    }
  }
}
```

---

## 📊 **Token Schema:**

### **Dimension Tokens (px → rem):**
```json
{
  "value": 16,           // Numeric value in px
  "type": "dimension",   // Token type
  "unit": "px",          // Source unit
  "comment": "..."       // Description
}
```

**Transform:** `16px / 16 = 1rem`

### **Font Family:**
```json
{
  "value": "'Public Sans', sans-serif",
  "type": "fontFamily",
  "comment": "..."
}
```

**Transform:** None (keep as is)

### **Font Weight:**
```json
{
  "value": 400,
  "type": "fontWeight",
  "comment": "..."
}
```

**Transform:** None (keep as number)

### **Number (unitless):**
```json
{
  "value": 1.5,
  "type": "number",
  "comment": "..."
}
```

**Transform:** None (keep as is)

### **Number with em:**
```json
{
  "value": 0.025,
  "type": "number",
  "unit": "em",
  "comment": "..."
}
```

**Transform:** `0.025em` (keep unit)

---

## 🔧 **Generator Logic:**

```javascript
// Base font size for conversion
const BASE_FONT_SIZE = 16;

function transform(token) {
  const { value, type, unit } = token;
  
  // px → rem conversion
  if (type === 'dimension' && unit === 'px') {
    if (value === 0) return '0';
    if (value >= 9999) return `${value}px`; // Keep large values
    return `${value / BASE_FONT_SIZE}rem`;
  }
  
  // em → keep as em
  if (type === 'number' && unit === 'em') {
    return `${value}em`;
  }
  
  // fontWeight → keep as number
  if (type === 'fontWeight') {
    return value;
  }
  
  // number → keep as is
  if (type === 'number') {
    return value;
  }
  
  // Default → keep as is
  return value;
}
```

---

## ✅ **Conversion Examples:**

| Token | Source (px) | Generated (rem) | Notes |
|-------|-------------|-----------------|-------|
| spacing-4 | 16px | 1rem | ✅ Standard |
| spacing-6 | 24px | 1.5rem | ✅ Standard |
| font-size-base | 16px | 1rem | ✅ Standard |
| font-size-xl | 20px | 1.25rem | ✅ Standard |
| radius-md | 6px | 0.375rem | ✅ Fit&Lead custom |
| radius-full | 9999px | 9999px | ✅ Kept as px |
| line-height-normal | 1.5 | 1.5 | ✅ Unitless |
| letter-spacing-wide | 0.025em | 0.025em | ✅ Kept as em |
| font-weight-bold | 700 | 700 | ✅ Number |

---

## 📦 **Complete Token Structure:**

```json
{
  "$description": "Fit&Lead Design Tokens - px canonical",
  "metadata": {
    "version": "0.1.0-manual",
    "date": "2025-01-04",
    "baseFontSize": 16,
    "unit": "px (canonical) → rem (generated)"
  },
  "spacing": {
    "0": { "value": 0, "type": "dimension", "unit": "px" },
    "1": { "value": 4, "type": "dimension", "unit": "px" },
    "4": { "value": 16, "type": "dimension", "unit": "px" }
  },
  "radius": {
    "md": { "value": 6, "type": "dimension", "unit": "px" },
    "full": { "value": 9999, "type": "dimension", "unit": "px" }
  },
  "typography": {
    "font-size-base": { "value": 16, "type": "dimension", "unit": "px" },
    "font-weight-bold": { "value": 700, "type": "fontWeight" },
    "line-height-normal": { "value": 1.5, "type": "number" },
    "letter-spacing-wide": { "value": 0.025, "type": "number", "unit": "em" }
  }
}
```

---

## 🎯 **Benefits:**

### **1. Figma Sync Ready:**
```
Figma: 16px
→ tokens.json: 16px ✅ Direct match
→ CSS: 1rem (auto-converted)
```

### **2. Multi-platform:**
```
tokens.json (px)
  ├→ Web: 1rem (generated)
  ├→ iOS: 16pt (future)
  ├→ Android: 16dp (future)
  └→ React Native: 16px (future)
```

### **3. Easy to Change Base:**
```javascript
// Change base from 16px → 18px
const BASE_FONT_SIZE = 18;
// All tokens auto-recalculate
// 24px / 18 = 1.333rem
```

### **4. Designer-Friendly:**
```
Designer says: "Make it 24px"
Developer adds: { "value": 24, "unit": "px" }
Generator outputs: 1.5rem
```

---

## 🚀 **Usage:**

### **Generate CSS:**
```bash
npm run tokens:build
# Output: app/globals.generated.css
```

### **Result:**
```css
/* Generated from tokens.json */
:root {
  --spacing-4: 1rem;        /* 16px */
  --spacing-6: 1.5rem;      /* 24px */
  --font-size-base: 1rem;   /* 16px */
  --radius-md: 0.375rem;    /* 6px */
  --radius-full: 9999px;    /* kept as px */
  --line-height-normal: 1.5; /* unitless */
  --letter-spacing-wide: 0.025em; /* em */
}
```

---

## ✅ **Validation:**

### **Test Cases:**
- ✅ 0px → `0` (no unit)
- ✅ 16px → `1rem`
- ✅ 24px → `1.5rem`
- ✅ 6px → `0.375rem` (Fit&Lead custom)
- ✅ 9999px → `9999px` (kept for border-radius: full)
- ✅ 1.5 (number) → `1.5`
- ✅ 0.025em → `0.025em`
- ✅ 700 (fontWeight) → `700`

---

## 📋 **Next Steps (Style Dictionary):**

### **Phase 2: Replace Simple Generator:**

```javascript
// style-dictionary.config.js
module.exports = {
  source: ['design-tokens/tokens.json'],
  platforms: {
    css: {
      transformGroup: 'css',
      transforms: ['size/pxToRem'],
      buildPath: 'build/css/',
      files: [{
        destination: 'variables.css',
        format: 'css/variables'
      }]
    },
    tailwind: {
      transformGroup: 'js',
      buildPath: 'build/js/',
      files: [{
        destination: 'tailwind.config.js',
        format: 'javascript/module'
      }]
    }
  }
}
```

---

## 🎉 **Status:**

- ✅ **tokens.json:** px canonical with type/unit
- ✅ **Generator:** px → rem transform working
- ✅ **CSS Output:** 159 lines, all values correct
- ✅ **Special cases:** 9999px, em, unitless handled
- ✅ **Ready for:** Style Dictionary migration

**Production-ready!** 🚀
